-- Subjective Questions

-- Q1. How does the toss decision affect the result of the match?
--  (which visualizations could be used to present your answer better) And is the impact limited to only specific venues?
SELECT
    v.Venue_Name,t.Toss_Name,
    COUNT(*) AS total_match,
    SUM(CASE WHEN Toss_Winner = Match_Winner THEN 1 ELSE 0 END) AS total_win,
    ROUND(100 * SUM(CASE WHEN Toss_Winner = Match_Winner THEN 1 ELSE 0 END) / COUNT(*), 2) AS win_percentage
FROM Matches m
JOIN Toss_Decision t ON t.Toss_Id = m.Toss_Decide
JOIN Venue v ON v.Venue_Id = m.Venue_Id
GROUP BY t.Toss_Name, m.Venue_Id, v.Venue_Name
ORDER BY m.Venue_Id, win_percentage DESC;



-- Q2. Suggest some of the players who would be best fit for the team.
-- for batsmen
SELECT 
     p.Player_Id, 
     p.Player_Name,
     COUNT(DISTINCT m.Match_Id) AS total_Match,
     SUM(b.Runs_Scored) AS total_run,
     ROUND(100 * SUM(b.Runs_Scored) / COUNT(b.Runs_Scored), 2) AS strike_rate
FROM ball_by_ball b
JOIN player p ON p.Player_Id = b.Striker
JOIN matches m ON m.Match_Id = b.Match_Id
GROUP BY p.Player_Name, p.Player_Id
ORDER BY total_run DESC, strike_rate DESC
LIMIT 10;


-- For Bowlers

WITH bolwer_season_wicket AS (
SELECT 
        m.Season_Id,b.Bowler,p.Player_Name,COUNT(DISTINCT b.Match_Id) AS total_matches,
        COUNT(b.Match_Id) AS total_ball,COUNT(w.Match_Id) AS total_wicket 
    FROM ball_by_ball b
    LEFT JOIN wicket_taken w ON w.Match_Id = b.Match_Id 
        AND w.Over_Id = b.Over_Id AND w.Ball_Id = b.Ball_Id AND w.Innings_No = b.Innings_No AND w.Kind_Out != 3    -- exclude run-outs
    LEFT JOIN player p ON p.Player_Id = b.Bowler
    LEFT JOIN matches m ON m.Match_Id = b.Match_Id
    GROUP BY b.Bowler, m.Season_Id, p.Player_Name)
SELECT 
    Player_Name,SUM(total_matches) AS total_match,SUM(total_wicket) AS total_wicket,
    ROUND(SUM(total_ball) / SUM(total_wicket), 2) AS bowling_strike_rate
FROM bolwer_season_wicket
GROUP BY Bowler, Player_Name
ORDER BY total_wicket DESC, total_match DESC, bowling_strike_rate
LIMIT 10;




-- Q4. Which players offer versatility in their skills and can contribute effectively with both bat and ball? (can you visualize the data for the same)

WITH Batting AS (SELECT b.Striker AS Player_Id,p.Player_Name,SUM(b.Runs_Scored) AS Total_Runs,ROUND(100 * SUM(b.Runs_Scored) / COUNT(b.Runs_Scored), 2) AS Strike_Rate
    FROM ball_by_ball b
    JOIN player p ON b.Striker = p.Player_Id
    GROUP BY b.Striker, p.Player_Name
),
Bowling AS (SELECT Bowler AS Player_Id,COUNT(w.Match_Id) AS Total_Wickets,ROUND(COUNT(b.Ball_Id) / NULLIF(COUNT(w.Match_Id), 0), 2) AS Bowling_Strike_Rate
    FROM ball_by_ball b
    LEFT JOIN wicket_taken w ON w.Match_Id = b.Match_Id AND w.Over_Id = b.Over_Id AND w.Ball_Id = b.Ball_Id AND w.Innings_No = b.Innings_No
    GROUP BY b.Bowler
),
AllRounders AS (SELECT bt.Player_Id,bt.Player_Name,bt.Total_Runs,bt.Strike_Rate,bw.Total_Wickets,bw.Bowling_Strike_Rate,
        ROUND((bt.Total_Runs / 50) + (bw.Total_Wickets * 2), 2) AS AllRound_Index
    FROM Batting bt
    JOIN Bowling bw ON bt.Player_Id = bw.Player_Id
    WHERE bt.Total_Runs > 200 AND bw.Total_Wickets > 5
)
SELECT *
FROM AllRounders
ORDER BY AllRound_Index DESC
LIMIT 10;



-- Q5. Are there players whose presence positively influences the morale and performance of the team? (justify your answer using visualization)

WITH player_win_percentage AS (SELECT p.Player_Id,p.Player_Name, pm.Team_Id,t.Team_Name,COUNT(m.Match_Id) AS Total_Matches, 
        SUM(CASE WHEN m.Match_Winner = pm.Team_Id THEN 1 ELSE 0 END) AS Matches_Won,
        ROUND(100 * SUM(CASE WHEN m.Match_Winner = pm.Team_Id THEN 1 ELSE 0 END) / COUNT(m.Match_Id), 2) AS win_percentage
    FROM player p
    JOIN player_match pm ON p.Player_Id = pm.Player_Id
    JOIN matches m ON pm.Match_Id = m.Match_Id
    JOIN team t ON t.Team_Id = pm.Team_Id
    WHERE m.Outcome_type = 1  -- ensures valid match results
    GROUP BY p.Player_Id, p.Player_Name, pm.Team_Id, t.Team_Name
    HAVING COUNT(m.Match_Id) > 10  -- filters for regular players
),
final AS (SELECT Player_Name,SUM(Total_Matches) AS Total_Matches,SUM(Matches_Won) AS Matches_Won,
ROUND(AVG(win_percentage), 2) AS win_percentage
    FROM player_win_percentage
    GROUP BY Player_Id, Player_Name 
)
SELECT * 
FROM final
ORDER BY win_percentage DESC
limit 10;



-- Q. 7 What do you think could be the factors contributing to the high-scoring matches and the impact on viewership and team strategies

-- Query 1 — Venue-Wise Average Runs per Match
SELECT 
    v.Venue_Name,
    ROUND(SUM(b.Runs_Scored) / COUNT(DISTINCT b.Match_Id), 2) AS Avg_Runs_Per_Match
FROM ball_by_ball b
JOIN matches m ON b.Match_Id = m.Match_Id
JOIN venue v ON m.Venue_Id = v.Venue_Id
GROUP BY v.Venue_Name
ORDER BY Avg_Runs_Per_Match DESC;

-- Query-2 Over-Phase Scoring Contribution

SELECT 
    CASE 
        WHEN b.Over_Id BETWEEN 1 AND 6 THEN 'Powerplay (1-6)'
        WHEN b.Over_Id BETWEEN 7 AND 15 THEN 'Middle Overs (7-15)'
        WHEN b.Over_Id BETWEEN 16 AND 20 THEN 'Death Overs (16-20)'
    END AS Over_Phase,
    ROUND(SUM(b.Runs_Scored) / COUNT(DISTINCT b.Match_Id), 2) AS Avg_Runs_Per_Match
FROM ball_by_ball b
GROUP BY Over_Phase
ORDER BY FIELD(Over_Phase, 'Powerplay (1-6)', 'Middle Overs (7-15)', 'Death Overs (16-20)');




-- Q8. Analyze the impact of home-ground advantage on team performance and identify strategies to maximize this advantage for RCB.
SELECT 
    CASE 
        WHEN v.Venue_Name = 'M Chinnaswamy Stadium' THEN 'Home'
        ELSE 'Away'
    END AS Match_Location,
    COUNT(*) AS Total_Matches,
    SUM(CASE WHEN m.Match_Winner = rcb.Team_Id THEN 1 ELSE 0 END) AS Matches_Won,
    ROUND(SUM(CASE WHEN m.Match_Winner = rcb.Team_Id THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS Win_Percentage
FROM matches m
JOIN team rcb ON (m.Team_1 = rcb.Team_Id OR m.Team_2 = rcb.Team_Id)
JOIN venue v ON m.Venue_Id = v.Venue_Id
WHERE rcb.Team_Name = 'Royal Challengers Bangalore'
GROUP BY Match_Location;



-- Q.9 Come up with a visual and analytical analysis of the RCB's past season's performance and potential reasons for them not winning a trophy.
-- QUERY 1: Season-wise Win Percentage
SELECT 
    s.Season_Year,
    COUNT(m.Match_Id) AS Total_Matches,
    SUM(CASE WHEN m.Match_Winner = t.Team_Id THEN 1 ELSE 0 END) AS Matches_Won,
    ROUND(SUM(CASE WHEN m.Match_Winner = t.Team_Id THEN 1 ELSE 0 END) * 100.0 / COUNT(m.Match_Id), 2) AS Win_Percentage
FROM matches m
JOIN season s ON m.Season_Id = s.Season_Id
JOIN team t ON (m.Team_1 = t.Team_Id OR m.Team_2 = t.Team_Id)
WHERE t.Team_Name = 'Royal Challengers Bangalore'
GROUP BY s.Season_Year
ORDER BY s.Season_Year;


-- QUERY 2: Season-wise Average Runs per Match 
SELECT 
    s.Season_Year,
    ROUND(SUM(b.Runs_Scored) / COUNT(DISTINCT b.Match_Id), 2) AS Avg_Runs_Per_Match
FROM ball_by_ball b
JOIN matches m ON b.Match_Id = m.Match_Id
JOIN season s ON m.Season_Id = s.Season_Id
JOIN team t ON b.Team_Batting = t.Team_Id
WHERE t.Team_Name = 'Royal Challengers Bangalore'
GROUP BY s.Season_Year
ORDER BY s.Season_Year;


-- Q. 11 In the "Match" table, some entries in the "Opponent_Team" column are incorrectly spelled as "Delhi_Capitals" instead of "Delhi_Daredevils".
--  Write an SQL query to replace all occurrences of "Delhi_Capitals" with "Delhi_Daredevils".

-- Verify current entry
SELECT Team_Id, Team_Name
FROM team
WHERE Team_Id = 6;

-- Backup the current record (optional but good practice)
CREATE TABLE IF NOT EXISTS team_backup AS
SELECT * FROM team;

-- Perform the update
UPDATE team
SET Team_Name = 'Delhi Daredevils'
WHERE Team_Id = 6;

-- Confirm the update worked
SELECT Team_Id, Team_Name
FROM team
WHERE Team_Id = 6;
