
-- 1.	List the different dtypes of columns in table “ball_by_ball” (using information schema)--

SELECT 
    COLUMN_NAME,
    DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'ipl'
  AND TABLE_NAME = 'Ball_by_Ball';
  
  
--  Q2 What is the total number of runs scored in 1st season by RCB (bonus: also include the extra runs using the extra runs table)
SELECT s.Season_Year,t.Team_Name,SUM(b.Runs_Scored + IFNULL(er.Extra_Runs, 0)) AS Total_Runs_Including_Extras
FROM ball_by_ball b
JOIN matches m ON b.Match_Id = m.Match_Id
JOIN season s ON m.Season_Id = s.Season_Id
JOIN team t ON b.Team_Batting = t.Team_Id
LEFT JOIN extra_runs er ON b.Match_Id = er.Match_Id AND b.Over_Id = er.Over_Id 
    AND b.Ball_Id = er.Ball_Id
WHERE s.Season_Year = (
        SELECT MIN(s2.Season_Year)
        FROM matches m2
        JOIN season s2 ON m2.Season_Id = s2.Season_Id
        WHERE m2.Team_1 = t.Team_Id OR m2.Team_2 = t.Team_Id
    )
  AND t.Team_Name = 'Royal Challengers Bangalore'
GROUP BY s.Season_Year, t.Team_Name;


-- Q3. How many players were more than the age of 25 during season 2014?


SELECT  count(DISTINCT p.player_id) AS num_of_player 
FROM player p 
JOIN player_match pm ON p.player_id = pm.player_id 
JOIN matches m ON pm.match_id = m.match_id 
JOIN season s ON m.season_id = s.season_id 
WHERE (2014-year(dob))>25
AND s.season_year = 2014;

-- Q4. How many matches did RCB win in 2013? 

select count(Match_Winner) as Win_count_by_RCB
from matches m
join team t on m.Match_Winner=t.Team_Id
join season s on s.Season_Id=m.Season_Id
where Season_Year=2013
and Team_Name ="Royal Challengers Bangalore";



-- Q5. List the top 10 players according to their strike rate in the last 4 seasons
SELECT 
    p.player_name,
    COUNT(*) AS total_balls_faced,
    SUM(b.runs_scored) AS total_runs,
    ROUND(SUM(b.runs_scored) * 100 / COUNT(*), 2) AS strike_rate
FROM ball_by_ball b
JOIN matches m ON b.match_id = m.match_id
JOIN season  s ON m.season_id = s.season_id
JOIN player  p ON b.striker = p.player_id
WHERE s.season_year >= (SELECT MAX(season_year) - 3 FROM season)
GROUP BY p.player_name
HAVING COUNT(*) >= 100 --  total_balls_faced>100
ORDER BY strike_rate DESC
LIMIT 10;

-- View for Top 10 hitters to show in visualizaton ppt horizontal bar chart
CREATE VIEW top_10_hitters AS 

 SELECT 
    p.player_name,
    COUNT(*) AS total_balls_faced,
    SUM(b.runs_scored) AS total_runs,
    ROUND(SUM(b.runs_scored) * 100 / COUNT(*), 2) AS strike_rate
FROM ball_by_ball b
JOIN matches m ON b.match_id = m.match_id
JOIN season  s ON m.season_id = s.season_id
JOIN player  p ON b.striker = p.player_id
WHERE s.season_year >= (SELECT MAX(season_year) - 3 FROM season)
GROUP BY p.player_name
HAVING COUNT(*) >= 100 --  total_balls_faced>100
ORDER BY strike_rate DESC
LIMIT 10;


-- Q6. What are the average runs scored by each batsman considering all the seasons?


SELECT 
    p.player_name,
    SUM(b.runs_scored) AS total_runs,
    COUNT(DISTINCT CONCAT(b.match_id, '-', b.innings_no)) AS innings_played,
    ROUND(SUM(b.runs_scored) / COUNT(DISTINCT CONCAT(b.match_id, '-', b.innings_no)), 2) AS avg_runs_per_innings
FROM ball_by_ball b 
JOIN player p ON b.striker = p.player_id 
GROUP BY p.player_name
HAVING innings_played >= 10
ORDER BY avg_runs_per_innings DESC;

-- Q7. What are the average wickets taken by each bowler considering all the seasons?

SELECT 
    p.Player_Name,
    COUNT(DISTINCT CONCAT(b.Match_Id, '-', b.Innings_No)) AS Innings_Bowled,
    COUNT(*) AS Total_Wickets,
    ROUND(COUNT(*) / COUNT(DISTINCT CONCAT(b.Match_Id, '-', b.Innings_No)), 2) AS Avg_Wickets_Per_Innings
FROM Wicket_Taken wt
JOIN Ball_by_Ball b 
      ON wt.Match_Id = b.Match_Id 
     AND wt.Over_Id = b.Over_Id 
     AND wt.Ball_Id = b.Ball_Id 
     AND wt.Innings_No = b.Innings_No
JOIN Player p 
      ON b.Bowler = p.Player_Id
GROUP BY p.Player_Name
HAVING Innings_Bowled >= 5
ORDER BY Avg_Wickets_Per_Innings DESC;


-- VIEW FOR Top_10_Bowlers_by_Average_Wickets_Per_Innings PPT  VISUALIZATION HORIZONTAL BARS
Create view Top_10_Bowlers_by_Average_Wickets_Per_Innings AS
SELECT 
    p.Player_Name,
    COUNT(DISTINCT CONCAT(b.Match_Id, '-', b.Innings_No)) AS Innings_Bowled,
    COUNT(*) AS Total_Wickets,
    ROUND(COUNT(*) / COUNT(DISTINCT CONCAT(b.Match_Id, '-', b.Innings_No)), 2) AS Avg_Wickets_Per_Innings
FROM Wicket_Taken wt
JOIN Ball_by_Ball b 
      ON wt.Match_Id = b.Match_Id 
     AND wt.Over_Id = b.Over_Id 
     AND wt.Ball_Id = b.Ball_Id 
     AND wt.Innings_No = b.Innings_No
JOIN Player p 
      ON b.Bowler = p.Player_Id
GROUP BY p.Player_Name
HAVING Innings_Bowled >= 5
ORDER BY Avg_Wickets_Per_Innings DESC
LIMIT 10;


-- Q8. List all the players who have average runs scored greater than the overall average
--  and who have taken wickets greater than the overall average

WITH batting_avg AS (SELECT b.Striker AS Player_Id,
        ROUND(SUM(b.Runs_Scored) / COUNT(DISTINCT CONCAT(b.Match_Id, '-', b.Innings_No)), 2) AS Avg_Runs
    FROM Ball_by_Ball b
    GROUP BY b.Striker),
    
bowling_avg AS (SELECT b.Bowler AS Player_Id,
        ROUND(COUNT(w.Player_Out) / COUNT(DISTINCT CONCAT(b.Match_Id, '-', b.Innings_No)), 2) AS Avg_Wickets
    FROM Ball_by_Ball b
    LEFT JOIN Wicket_Taken w 
           ON b.Match_Id = w.Match_Id AND b.Over_Id = w.Over_Id AND b.Ball_Id = w.Ball_Id AND b.Innings_No = w.Innings_No
    GROUP BY b.Bowler),

overall_avg AS (SELECT (SELECT AVG(Avg_Runs) FROM batting_avg)   AS Overall_Bat_Avg,
(SELECT AVG(Avg_Wickets) FROM bowling_avg) AS Overall_Bowl_Avg)
SELECT 
    p.Player_Name,ba.Avg_Runs,bo.Avg_Wickets
FROM batting_avg ba
JOIN bowling_avg bo ON ba.Player_Id = bo.Player_Id
JOIN overall_avg oa
JOIN Player p ON ba.Player_Id = p.Player_Id
WHERE ba.Avg_Runs > oa.Overall_Bat_Avg AND bo.Avg_Wickets > oa.Overall_Bowl_Avg
ORDER BY ba.Avg_Runs DESC, bo.Avg_Wickets DESC;

-- Q9. Create a table rcb_record table that shows the wins and losses of RCB in an individual venue.
DROP TABLE IF EXISTS rcb_record ;
CREATE TABLE rcb_record AS
SELECT 
    v.Venue_Name,
    COUNT(*) AS Matches_Played,
    SUM(CASE WHEN t.Team_Name = 'Royal Challengers Bangalore'
                  AND m.Match_Winner = t.Team_Id THEN 1 ELSE 0 END) AS Wins,
    SUM(CASE WHEN (t.Team_Name = 'Royal Challengers Bangalore') 
                  AND (m.Match_Winner <> t.Team_Id) 
                  AND (m.Outcome_Type IS NOT NULL) THEN 1 ELSE 0 END) AS Losses
FROM Matches m
JOIN Team t 
     ON (m.Team_1 = t.Team_Id OR m.Team_2 = t.Team_Id)
JOIN Venue v 
     ON m.Venue_Id = v.Venue_Id
WHERE t.Team_Name = 'Royal Challengers Bangalore'
GROUP BY v.Venue_Name;

--  View the table
SELECT * FROM rcb_record
ORDER BY Wins DESC;

-- Q10. What is the impact of bowling style on wickets taken?

WITH style_wickets AS (
    SELECT bs.Bowling_Skill AS Bowling_Style,COUNT(w.Player_Out) AS Total_Wickets,
        COUNT(DISTINCT b.Bowler) AS Bowlers_Count,
        ROUND(COUNT(w.Player_Out) / COUNT(DISTINCT b.Bowler), 2) AS Avg_Wickets_Per_Bowler
    FROM Wicket_Taken w
    JOIN Ball_by_Ball b 
          ON w.Match_Id = b.Match_Id
         AND w.Over_Id = b.Over_Id
         AND w.Ball_Id = b.Ball_Id
         AND w.Innings_No = b.Innings_No
    JOIN Player p ON b.Bowler = p.Player_Id
    JOIN Bowling_Style bs ON p.Bowling_Skill = bs.Bowling_Id
    GROUP BY bs.Bowling_Skill
)
SELECT 
    Bowling_Style,
    Total_Wickets,
    Bowlers_Count,
    Avg_Wickets_Per_Bowler
FROM style_wickets
ORDER BY Avg_Wickets_Per_Bowler DESC;

-- Q11. Write the SQL query to provide a status of whether the performance of the team is better than the previous year's performance on the basis of the number of runs scored by the team in the season and the number of wickets taken 
WITH team_runs AS (SELECT t.Team_Name,s.Season_Year,SUM(b.Runs_Scored) + IFNULL(SUM(e.Extra_Runs),0) AS Total_Runs
    FROM Ball_by_Ball b JOIN Matches m ON b.Match_Id = m.Match_Id JOIN Season  s ON m.Season_Id = s.Season_Id
    JOIN Team    t ON b.Team_Batting = t.Team_Id
    LEFT JOIN Extra_Runs e ON b.Match_Id   = e.Match_Id AND b.Over_Id = e.Over_Id AND b.Ball_Id  = e.Ball_Id AND b.Innings_No = e.Innings_No
    WHERE t.Team_Name = 'Royal Challengers Bangalore'
    GROUP BY t.Team_Name, s.Season_Year
),
team_wickets AS (SELECT t.Team_Name,s.Season_Year,COUNT(w.Player_Out) AS Total_Wickets
    FROM Wicket_Taken w
    JOIN Ball_by_Ball b ON w.Match_Id = b.Match_Id AND w.Over_Id = b.Over_Id AND w.Ball_Id = b.Ball_Id 
    AND w.Innings_No = b.Innings_No
    JOIN Matches m ON b.Match_Id = m.Match_Id JOIN Season  s ON m.Season_Id = s.Season_Id
    JOIN Team    t ON b.Team_Bowling = t.Team_Id WHERE t.Team_Name = 'Royal Challengers Bangalore'    GROUP BY t.Team_Name, s.Season_Year
),
combined AS (SELECT r.Team_Name,r.Season_Year,r.Total_Runs,w.Total_Wickets
    FROM team_runs r JOIN team_wickets w ON r.Team_Name = w.Team_Name AND r.Season_Year = w.Season_Year
),
performance AS (SELECT Team_Name,Season_Year,Total_Runs,Total_Wickets,
        LAG(Total_Runs) OVER (PARTITION BY Team_Name ORDER BY Season_Year) AS Prev_Runs,
        LAG(Total_Wickets) OVER (PARTITION BY Team_Name ORDER BY Season_Year) AS Prev_Wkts FROM combined
)
SELECT Team_Name,Season_Year,Total_Runs,Total_Wickets,CASE WHEN Total_Runs > Prev_Runs AND Total_Wickets > Prev_Wkts THEN 'Better Overall'
        WHEN Total_Runs > Prev_Runs THEN 'Better Batting' WHEN Total_Wickets > Prev_Wkts THEN 'Better Bowling' ELSE 'Poor Performance than Previous'
    END AS Performance_Status FROM performance
ORDER BY Season_Year;


-- 13.	Using SQL, write a query to find out the average wickets taken by each bowler in each venue. Also, rank the gender according to the average value.

WITH bowler_venue_stats AS (SELECT  p.Player_Name,v.Venue_Name,COUNT(w.Player_Out) AS Total_Wickets,COUNT(DISTINCT b.Match_Id) AS Matches_Played,
        ROUND(COUNT(w.Player_Out) / COUNT(DISTINCT b.Match_Id), 2) AS Avg_Wickets_Per_Match
    FROM Wicket_Taken w
    JOIN Ball_by_Ball b ON w.Match_Id = b.Match_Id AND w.Over_Id = b.Over_Id AND w.Ball_Id = b.Ball_Id AND w.Innings_No = b.Innings_No
    JOIN Player p ON b.Bowler = p.Player_Id
    JOIN Matches m ON b.Match_Id = m.Match_Id
    JOIN Venue v ON m.Venue_Id = v.Venue_Id
    GROUP BY p.Player_Name, v.Venue_Name
)
SELECT 
    Player_Name,
    Venue_Name,
    Total_Wickets,
    Matches_Played,
    Avg_Wickets_Per_Match,
    RANK() OVER (PARTITION BY Venue_Name ORDER BY Avg_Wickets_Per_Match DESC) AS Venue_Rank
FROM bowler_venue_stats
ORDER BY Venue_Name, Venue_Rank;

-- Q14. Which of the given players have consistently performed well in past seasons? (will you use any visualization to solve the problem)
WITH PlayerPerformance AS (SELECT p.Player_Name,s.Season_Year,ROUND(SUM(b.Runs_Scored) / COUNT(DISTINCT b.Match_Id), 2) AS Avg_Runs_Per_Match
    FROM Ball_by_Ball b
    JOIN Matches m ON b.Match_Id = m.Match_Id
    JOIN Season s ON m.Season_Id = s.Season_Id
    JOIN Player p ON b.Striker = p.Player_Id
    GROUP BY p.Player_Name, s.Season_Year),
ConsistencyScore AS (SELECT Player_Name,ROUND(AVG(Avg_Runs_Per_Match), 2) AS Overall_Avg,ROUND(STDDEV(Avg_Runs_Per_Match), 2) AS Performance_Variation
    FROM PlayerPerformance
    GROUP BY Player_Name)
    
SELECT Player_Name,Overall_Avg,Performance_Variation,
    CASE 
        WHEN Performance_Variation <= 5 THEN 'Highly Consistent'
        WHEN Performance_Variation <= 10 THEN 'Moderately Consistent'
        ELSE 'Inconsistent'
    END AS Consistency_Level
FROM ConsistencyScore
ORDER BY Overall_Avg DESC, Performance_Variation ASC;

-- 15.	Are there players whose performance is more suited to specific venues or conditions? (how would you present this using charts?) 
-- for Batsmen
SELECT v.Venue_Name,p.Player_Name,SUM(b.Runs_Scored) AS total_run,COUNT( DISTINCT m.Match_Id) AS total_match,
ROUND(SUM(b.Runs_Scored) / COUNT( DISTINCT m.Match_Id), 2) AS avg_venue_run,ROUND(100 * SUM(b.Runs_Scored) / COUNT(b.Runs_Scored), 2) AS strike_rate
FROM ball_by_ball b
JOIN matches m ON b.Match_Id = m.Match_Id
JOIN player p ON p.Player_Id = b.Striker
JOIN venue v ON v.Venue_Id = m.Venue_Id
WHERE NOT EXISTS (
    SELECT 1 FROM extra_runs e WHERE b.Match_Id = e.Match_Id
      AND b.Over_Id = e.Over_Id AND b.Ball_Id = e.Ball_Id AND e.Extra_Type_Id NOT IN(1,3)
      AND b.Innings_No = e.Innings_No) 
GROUP BY b.Striker, m.Venue_Id, p.Player_Name
HAVING SUM(b.Runs_Scored) > 200
ORDER BY total_run DESC, avg_venue_run DESC, total_match DESC;


-- for bowler--
SELECT v.Venue_Name,p.Player_Name,COUNT( DISTINCT b.Match_Id) AS total_matches,COUNT(w.Match_Id) as total_wicket
FROM ball_by_ball b
LEFT JOIN wicket_taken w ON w.Match_Id = b.Match_Id AND w.Over_Id = b.Over_Id AND w.Ball_Id = b.Ball_Id 
	 AND w.Innings_No = b.Innings_No AND w.Kind_Out != 3
LEFT JOIN player p ON p.Player_Id = b.Bowler
LEFT JOIN Matches m ON m.Match_Id = b.Match_Id
LEFT JOIN venue v ON v.Venue_Id = m.Venue_Id
where w.Match_Id>10
	 GROUP BY b.Bowler, v.Venue_Id, v.Venue_Name, p.Player_Name
     having COUNT(w.Match_Id)>=10
ORDER BY total_wicket DESC, total_matches DESC;




 






